# Changelog

## 0.1.0 — 2026-11-02

First release, merging the share channels of Schooldo (`share-capabilities.ts`, channel actions)
and Bufoo (`publicShare.ts`): `SHARE_CHANNELS`, `parseShareChannels`, `supportsSms`,
`availableShareChannels`, `shareMessage`, `phoneDigits`, `shareAction` with an optional
recipient for WhatsApp, SMS and email; `SHARE_STANDALONE_SOURCE` for static pages.
