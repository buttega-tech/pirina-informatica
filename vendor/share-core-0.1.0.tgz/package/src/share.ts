// Sharing a link through the channels a person already uses: the channel list, what each device
// can open, and the exact action for a channel (a URL to open, the native sheet, text to copy or
// a link to show as a QR code). No DOM, no clipboard, no QR drawing, no wording.

export const SHARE_CHANNELS = ["native", "whatsapp", "telegram", "sms", "email", "facebook", "x", "linkedin", "qr", "copy"] as const;
export type ShareChannel = (typeof SHARE_CHANNELS)[number];

/** title: email subject and native sheet title; text: the message before the link;
 * to: an optional recipient (phone in international format for whatsapp/sms, address for email). */
export type SharePayload = { url: string; title?: string | null; text?: string | null; to?: string | null };

export type ShareAction =
  | { kind: "open"; href: string }
  | { kind: "native"; data: { title?: string; text?: string; url: string }; fallbackText: string }
  | { kind: "copy"; text: string }
  | { kind: "qr"; url: string };

export type ShareEnvironment = { userAgent: string; platform?: string; maxTouchPoints?: number };

export function isShareChannel(value: unknown): value is ShareChannel {
  return typeof value === "string" && (SHARE_CHANNELS as readonly string[]).includes(value);
}

/** Known channels from stored settings, without duplicates, in their stored order; null when none. */
export function parseShareChannels(value: unknown): ShareChannel[] | null {
  if (!Array.isArray(value)) return null;
  const channels = [...new Set(value.filter(isShareChannel))];
  return channels.length ? channels : null;
}

// The browser cannot tell whether an sms: handler exists. These systems ship one:
// Messages on iOS, iPadOS and macOS (also via a paired iPhone) and the Android SMS app.
export function supportsSms({ userAgent, platform = "", maxTouchPoints = 0 }: ShareEnvironment) {
  if (/Android|iPhone|iPod/i.test(userAgent)) return true;
  // iPadOS reports a Mac desktop user agent; Macs themselves also handle sms:.
  return /Macintosh|Mac OS X|iPad/i.test(userAgent) || /^(mac|ipad)/i.test(platform) || (platform === "MacIntel" && maxTouchPoints > 1);
}

/** The channels this device can open: the native sheet only where it exists, SMS only where a handler ships. */
export function availableShareChannels(channels: readonly ShareChannel[], device: { native: boolean; sms: boolean }) {
  return channels.filter((channel) => channel === "native" ? device.native : channel === "sms" ? device.sms : true);
}

/** The message as sent by text channels: the text, then the link on its own line. */
export function shareMessage(payload: SharePayload) {
  return [payload.text?.trim(), payload.url].filter(Boolean).join("\n");
}

/** Digits of an international phone number ("+39 329 …", "0039…"), or "" when it is not one. */
export function phoneDigits(value: string | null | undefined) {
  const digits = String(value ?? "").replace(/^\s*(\+|00)/, "").replace(/[\s().-]/g, "");
  return /^[1-9][0-9]{6,14}$/.test(digits) ? digits : "";
}

function emailAddress(value: string | null | undefined) {
  const address = String(value ?? "").trim();
  return /^[^\s@<>?&]+@[^\s@<>?&]+\.[^\s@<>?&]+$/.test(address) ? address : "";
}

/** What to do for a channel. copy: "url" copies the link, "message" the whole message. */
export function shareAction(channel: ShareChannel, payload: SharePayload, options: { copy?: "url" | "message" } = {}): ShareAction {
  const url = payload.url, text = payload.text?.trim() ?? "", title = payload.title?.trim() ?? "";
  const message = shareMessage(payload), encoded = encodeURIComponent;
  if (channel === "native") return { kind: "native", data: { ...(title ? { title } : {}), ...(text ? { text } : {}), url }, fallbackText: message };
  if (channel === "copy") return { kind: "copy", text: options.copy === "message" ? message : url };
  if (channel === "qr") return { kind: "qr", url };
  if (channel === "whatsapp") return { kind: "open", href: `https://wa.me/${phoneDigits(payload.to)}?text=${encoded(message)}` };
  if (channel === "telegram") return { kind: "open", href: `https://t.me/share/url?url=${encoded(url)}&text=${encoded(text || title)}` };
  if (channel === "sms") {
    const to = phoneDigits(payload.to);
    return { kind: "open", href: `sms:${to ? "+" + to : ""}?&body=${encoded(message)}` };
  }
  if (channel === "email") return { kind: "open", href: `mailto:${encoded(emailAddress(payload.to)).replace("%40", "@")}?subject=${encoded(title)}&body=${encoded(message)}` };
  if (channel === "facebook") return { kind: "open", href: `https://www.facebook.com/sharer/sharer.php?u=${encoded(url)}` };
  if (channel === "x") return { kind: "open", href: `https://x.com/intent/post?url=${encoded(url)}&text=${encoded(text || title)}` };
  if (channel === "linkedin") return { kind: "open", href: `https://www.linkedin.com/sharing/share-offsite/?url=${encoded(url)}` };
  throw new Error(`Unknown share channel: ${String(channel)}`);
}
