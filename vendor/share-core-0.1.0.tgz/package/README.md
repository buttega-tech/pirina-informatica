# @bottega/share-core

Share a link through the channels people already use, with no DOM, clipboard, QR drawing or
wording. A project renders its own buttons and labels and performs the returned action.

## What it covers

- **Channels**: `SHARE_CHANNELS` = `native` (system share sheet), `whatsapp`, `telegram`, `sms`,
  `email`, `facebook`, `x`, `linkedin`, `qr`, `copy`. `parseShareChannels` reads a stored list
  (known channels, once, in order; `null` when none).
- **Device**: `availableShareChannels(channels, { native, sms })` hides the native sheet where
  `navigator.share` is missing and SMS where no handler ships (`supportsSms` from the user agent).
- **Action**: `shareAction(channel, payload, { copy })` returns
  `{ kind: "open", href }` (open in the same tab), `{ kind: "native", data, fallbackText }`
  (`navigator.share(data)`, or copy `fallbackText`), `{ kind: "copy", text }` or `{ kind: "qr", url }`.
  `copy: "message"` copies the whole message instead of the bare link.
- **Recipient**: `payload.to` sends straight to someone: an international phone number for
  WhatsApp (`wa.me/<digits>`) and SMS, an address for email. An unusable value is dropped, so the
  person picks the recipient in the app.
- **Message**: text channels send `text`, then the link on its own line (`shareMessage`).
  Telegram and X take the link plus `text` (or `title`); email uses `title` as the subject.
- **Page scripts**: `SHARE_STANDALONE_SOURCE` is the same code as one self-contained expression
  (`new Function(\`return ${source}\`)()`), generated from `src/share.ts` by
  `node scripts/standalone.mjs` and checked by the tests.

## Consumers

- Pirina Informatica operator page (0.1.0): «Invita amministratore» sends a single-use activation
  link; the page build writes the inline source as `/share-core.js`.

Schooldo (`share-channel-actions.tsx`, `share-capabilities.ts`) and Bufoo
(`lib/social/publicShare.ts`) have the original implementations this library merges; adopting it
there is a project lane each. Known differences: Bufoo joins text and link with a space and uses
«Condivisione» as default email subject; here the separator is a new line and the subject is
the payload title (empty when missing).

## Not here

Labels, icons, brand colours, which channels a product enables, QR rendering (needs a QR
encoder; Schooldo uses `qrcode`), clipboard and `window.open` calls, and the content of the
shared link (invite tokens, public pages): they belong to each project.

## Tests

```sh
node scripts/standalone.mjs --check && node --test tests/*.test.mjs   # Node 24
```
